classes_names = {'Flyweight':{},
				'ConcreteFlyweight': {'inh': 'Flyweight'},
				'UnsharedConFlyweight': {'inh': 'Flyweight'},
				'FlyweightFactory': {'agg': 'Flyweight'},
				}

classes_def = "public class"
for class_name, class_content in classes_names.iteritems():
	f = open("%s.java" % class_name, "w")
	f.write("%s %s " % (classes_def, class_name))
	if "inh" in class_content.keys():
		f.write("extends %s " % class_content.get("inh"))
	f.write("{\n")
	f.write("\n")
	if "ass" in class_content.keys():
		ass_string = "%s ass_obj = new %s();" % (class_content.get("ass"), class_content.get("ass"))
		f.write(ass_string)
		f.write("\n")
	if "agg" in class_content.keys():
		agg_string_obj = "public static final %s agg_obj = new %s();" % ((class_content.get("agg"), class_content.get("agg")))
		f.write(agg_string_obj)
		f.write("\n")
		agg_method = "public static %s addAggregation() {return agg_obj;}" % class_content.get("agg")
		f.write(agg_method)
		f.write("\n")
	if "dep" in class_content.keys():
		dep_method = "public static void depMethod() {%s.SomeStaticMethod();}" % class_content.get("dep")
		f.write(dep_method)
		f.write("\n")
	f.write("}")
	print "%s %s = new %s();" % (class_name, class_name.lower(), class_name)
	
	