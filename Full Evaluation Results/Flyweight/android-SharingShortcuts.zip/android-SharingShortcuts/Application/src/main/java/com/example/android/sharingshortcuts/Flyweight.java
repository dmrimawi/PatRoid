public class Flyweight {

}