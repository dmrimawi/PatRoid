public class UnsharedConFlyweight extends Flyweight {

}