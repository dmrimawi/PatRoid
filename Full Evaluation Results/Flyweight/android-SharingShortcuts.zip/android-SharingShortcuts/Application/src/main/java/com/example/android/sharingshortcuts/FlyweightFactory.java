public class FlyweightFactory {

public static final Flyweight agg_obj = new Flyweight();
public static Flyweight addAggregation() {return agg_obj;}
}