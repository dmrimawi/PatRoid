public class ConcreteFlyweight extends Flyweight {

}