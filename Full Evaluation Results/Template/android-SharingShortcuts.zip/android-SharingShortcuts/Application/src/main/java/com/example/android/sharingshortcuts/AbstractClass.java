public class AbstractClass {

}