public class ConcreteClassA extends AbstractClass {

}