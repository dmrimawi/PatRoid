public class ConcreteClassB extends AbstractClass {

}