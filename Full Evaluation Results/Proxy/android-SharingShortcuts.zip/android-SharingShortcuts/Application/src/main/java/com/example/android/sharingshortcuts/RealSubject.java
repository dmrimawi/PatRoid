public class RealSubject extends Subject {

Proxy ass_obj = new Proxy();
}