public class Proxy extends Subject {

}