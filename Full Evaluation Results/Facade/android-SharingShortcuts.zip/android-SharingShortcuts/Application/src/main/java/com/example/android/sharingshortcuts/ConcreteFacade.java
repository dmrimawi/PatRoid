public class ConcreteFacade extends Facade {

}