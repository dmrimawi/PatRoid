public class SubSysterm3 {

public static void depMethod() {ConcreteFacade.SomeStaticMethod();}
}