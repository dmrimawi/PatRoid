public class SubSysterm2 {

public static void depMethod() {ConcreteFacade.SomeStaticMethod();}
}