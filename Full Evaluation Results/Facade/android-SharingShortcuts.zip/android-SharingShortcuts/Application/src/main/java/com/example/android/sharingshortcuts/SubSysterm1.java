public class SubSysterm1 {

public static void depMethod() {ConcreteFacade.SomeStaticMethod();}
}