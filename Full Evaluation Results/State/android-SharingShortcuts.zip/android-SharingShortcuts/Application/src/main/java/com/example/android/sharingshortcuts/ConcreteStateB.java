public class ConcreteStateB extends State {

}