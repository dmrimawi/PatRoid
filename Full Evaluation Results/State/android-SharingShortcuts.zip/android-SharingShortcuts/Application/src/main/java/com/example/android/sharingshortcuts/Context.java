public class Context {

public static final State agg_obj = new State();
public static State addAggregation() {return agg_obj;}
}