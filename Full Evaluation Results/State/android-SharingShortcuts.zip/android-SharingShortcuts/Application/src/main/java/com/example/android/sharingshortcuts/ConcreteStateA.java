public class ConcreteStateA extends State {

}