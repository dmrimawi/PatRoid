public class Aggregate {

}