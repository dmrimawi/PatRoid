public class ConcreteAggregate extends Aggregate {

ConcreteIterator ass_obj = new ConcreteIterator();
}