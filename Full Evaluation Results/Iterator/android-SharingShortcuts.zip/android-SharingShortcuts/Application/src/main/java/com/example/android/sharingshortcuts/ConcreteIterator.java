public class ConcreteIterator extends Iterator {

public static void depMethod() {ConcreteAggregate.SomeStaticMethod();}
}