public class ConcreteComp extends Comp {

}