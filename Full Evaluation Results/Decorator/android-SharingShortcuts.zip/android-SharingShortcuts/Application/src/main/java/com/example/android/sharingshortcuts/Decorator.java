public class Decorator extends Comp {

public static final Comp agg_obj = new Comp();
public static Comp addAggregation() {return agg_obj;}
}