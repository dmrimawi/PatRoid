public class ConcreteDecoratorA extends Decorator {

}