public class ConcreteDecoratorB extends Decorator {

}