public class AbstractProduct {

}