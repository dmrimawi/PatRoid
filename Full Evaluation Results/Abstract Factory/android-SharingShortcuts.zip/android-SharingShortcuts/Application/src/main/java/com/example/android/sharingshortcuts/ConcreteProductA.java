public class ConcreteProductA extends AbstractProduct {

public static void depMethod() {ConcreteFactory.SomeStaticMethod();}
}