public class ConcreteProductB extends AbstractProduct {

public static void depMethod() {ConcreteFactory.SomeStaticMethod();}
}