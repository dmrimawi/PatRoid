public class ConcreteFactory extends AbstractFactory {

}