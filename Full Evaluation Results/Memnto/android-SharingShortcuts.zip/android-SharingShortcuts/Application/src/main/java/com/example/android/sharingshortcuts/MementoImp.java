public class MementoImp extends Memento {

}