public class Caretaker {

public static final Memento agg_obj = new Memento();
public static Memento addAggregation() {return agg_obj;}
}