public class Memento {

public static void depMethod() {Orginator.SomeStaticMethod();}
}