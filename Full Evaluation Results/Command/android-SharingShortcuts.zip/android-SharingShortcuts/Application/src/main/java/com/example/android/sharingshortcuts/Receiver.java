public class Receiver {

ConcreteCommand ass_obj = new ConcreteCommand();
}