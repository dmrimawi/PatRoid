public class Invoker {

public static final Command agg_obj = new Command();
public static Command addAggregation() {return agg_obj;}
}