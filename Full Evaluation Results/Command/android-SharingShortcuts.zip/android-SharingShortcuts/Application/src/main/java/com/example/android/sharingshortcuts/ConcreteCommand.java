public class ConcreteCommand extends Command {

}