public class Abstraction {

public static final Implementor agg_obj = new Implementor();
public static Implementor addAggregation() {return agg_obj;}
}