public class ConcreteImplementorB extends Implementor {

}