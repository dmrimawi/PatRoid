public class RefinedAbstraction extends Abstraction {

}