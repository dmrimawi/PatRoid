public class ConcreteImplementorA extends Implementor {

}