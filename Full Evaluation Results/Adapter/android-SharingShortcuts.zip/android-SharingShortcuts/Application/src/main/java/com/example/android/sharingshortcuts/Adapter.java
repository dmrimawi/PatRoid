public class Adapter extends Target {

}