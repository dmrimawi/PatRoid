public class Adaptee {

Adapter ass_obj = new Adapter();
}