public class ConcreteProduct extends Product {

public static void depMethod() {ConcreteCreator.SomeStaticMethod();}
}