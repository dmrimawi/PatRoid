public class Product {

}