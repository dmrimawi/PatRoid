public class ConcreteCreator extends Creator {

}