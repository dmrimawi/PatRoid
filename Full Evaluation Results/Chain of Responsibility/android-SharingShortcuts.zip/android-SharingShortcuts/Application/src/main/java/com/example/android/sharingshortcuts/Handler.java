public class Handler {

Handler ass_obj = new Handler();
}