public class ConcreteHandlerA extends Handler {

}