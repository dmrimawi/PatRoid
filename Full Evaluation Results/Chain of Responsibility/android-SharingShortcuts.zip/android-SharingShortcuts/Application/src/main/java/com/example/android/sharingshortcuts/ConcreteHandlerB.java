public class ConcreteHandlerB extends Handler {

}