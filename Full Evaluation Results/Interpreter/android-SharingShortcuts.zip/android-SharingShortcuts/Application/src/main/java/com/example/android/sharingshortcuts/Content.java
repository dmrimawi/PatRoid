public class Content {

public static void depMethod() {AbstractExpression.SomeStaticMethod();}
}