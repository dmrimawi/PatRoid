public class NonterminalExpression extends AbstractExpression {

public static final AbstractExpression agg_obj = new AbstractExpression();
public static AbstractExpression addAggregation() {return agg_obj;}
}