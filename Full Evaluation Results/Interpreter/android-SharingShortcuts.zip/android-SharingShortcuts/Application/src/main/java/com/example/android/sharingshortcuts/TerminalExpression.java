public class TerminalExpression extends AbstractExpression {

}