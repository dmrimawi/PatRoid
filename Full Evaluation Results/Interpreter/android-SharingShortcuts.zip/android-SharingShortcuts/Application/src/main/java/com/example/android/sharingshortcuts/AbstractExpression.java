public class AbstractExpression {

}