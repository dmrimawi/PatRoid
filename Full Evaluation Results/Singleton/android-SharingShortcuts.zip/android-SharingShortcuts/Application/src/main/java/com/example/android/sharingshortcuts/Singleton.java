public class Singleton {

Singleton ass_obj = new Singleton();
}