public class Strategy {

}