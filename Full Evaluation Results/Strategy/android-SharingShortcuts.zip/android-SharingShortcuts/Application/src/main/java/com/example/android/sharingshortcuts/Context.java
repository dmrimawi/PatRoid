public class Context {

public static final Strategy agg_obj = new Strategy();
public static Strategy addAggregation() {return agg_obj;}
}