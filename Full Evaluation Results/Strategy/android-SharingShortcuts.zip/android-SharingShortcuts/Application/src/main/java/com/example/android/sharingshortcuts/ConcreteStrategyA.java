public class ConcreteStrategyA extends Strategy {

}