public class ConcreteStrategyB extends Strategy {

}