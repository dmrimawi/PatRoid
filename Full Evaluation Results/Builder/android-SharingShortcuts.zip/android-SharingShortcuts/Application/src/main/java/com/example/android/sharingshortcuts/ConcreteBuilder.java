public class ConcreteBuilder extends Builder {

}