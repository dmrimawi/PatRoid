public class Product {

ConcreteBuilder ass_obj = new ConcreteBuilder();
}