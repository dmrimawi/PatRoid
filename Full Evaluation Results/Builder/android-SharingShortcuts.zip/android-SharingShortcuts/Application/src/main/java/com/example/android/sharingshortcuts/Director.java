public class Director {

public static final Builder agg_obj = new Builder();
public static Builder addAggregation() {return agg_obj;}
}