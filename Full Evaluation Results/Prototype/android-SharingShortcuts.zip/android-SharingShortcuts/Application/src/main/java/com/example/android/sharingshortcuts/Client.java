public class Client {

public static final Prototype agg_obj = new Prototype();
public static Prototype addAggregation() {return agg_obj;}
}