public class ConcretePrototypeB extends Prototype {

}