public class Prototype {

}