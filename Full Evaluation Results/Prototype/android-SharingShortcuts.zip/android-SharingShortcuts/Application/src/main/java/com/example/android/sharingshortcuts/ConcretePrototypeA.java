public class ConcretePrototypeA extends Prototype {

}