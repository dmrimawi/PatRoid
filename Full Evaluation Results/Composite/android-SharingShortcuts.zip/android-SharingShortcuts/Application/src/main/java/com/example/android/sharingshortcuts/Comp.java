public class Comp {

    public static final Composite composite = new Composite();
	public static Composite aggComposite() {
        return composite;
    }
}
