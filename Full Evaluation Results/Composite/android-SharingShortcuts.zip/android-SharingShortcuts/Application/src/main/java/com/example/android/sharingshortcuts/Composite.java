
public class Composite extends Comp {

}
