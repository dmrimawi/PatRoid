public class ConcreteColleagueB extends Colleague {

ConcreteMediator ass_obj = new ConcreteMediator();
}