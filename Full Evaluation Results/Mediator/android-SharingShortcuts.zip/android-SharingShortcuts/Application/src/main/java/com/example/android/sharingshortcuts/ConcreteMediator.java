public class ConcreteMediator extends Mediator {

}