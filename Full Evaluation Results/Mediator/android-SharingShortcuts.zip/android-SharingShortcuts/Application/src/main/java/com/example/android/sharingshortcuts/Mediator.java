public class Mediator {

Colleague ass_obj = new Colleague();
}