public class ConcreteColleagueA extends Colleague {

ConcreteMediator ass_obj = new ConcreteMediator();
}