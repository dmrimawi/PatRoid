public class Colleague {

}