public class ConcreteObserver extends Observer {

}