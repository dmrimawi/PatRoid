public class ConcreteSubject extends Subject {

public static void depMethod() {ConcreteObserver.SomeStaticMethod();}
}