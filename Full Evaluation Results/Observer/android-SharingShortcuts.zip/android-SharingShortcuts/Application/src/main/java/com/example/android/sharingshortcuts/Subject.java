public class Subject {

public static final Observer agg_obj = new Observer();
public static Observer addAggregation() {return agg_obj;}
}