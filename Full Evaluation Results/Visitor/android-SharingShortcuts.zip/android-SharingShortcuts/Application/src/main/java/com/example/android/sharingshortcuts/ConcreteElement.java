public class ConcreteElement extends Element {

public static void depMethod() {ConcreteVisitor.SomeStaticMethod();}
}