public class Visitor {

public static void depMethod() {Element.SomeStaticMethod();}
}