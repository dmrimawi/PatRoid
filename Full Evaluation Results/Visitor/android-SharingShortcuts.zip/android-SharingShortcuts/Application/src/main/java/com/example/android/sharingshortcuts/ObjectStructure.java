public class ObjectStructure {

public static final Element agg_obj = new Element();
public static Element addAggregation() {return agg_obj;}
}