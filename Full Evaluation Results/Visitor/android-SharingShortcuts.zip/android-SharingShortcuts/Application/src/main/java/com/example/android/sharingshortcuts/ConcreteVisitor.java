public class ConcreteVisitor extends Visitor {

}